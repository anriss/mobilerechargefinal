package com.cg.dao;

import com.cg.beans.Account;

public interface AccountDAO {
	Account getDetails(String mobileNumber);
	double rechargeAccount(String mobileNumber,double rechargeAmount);
}
