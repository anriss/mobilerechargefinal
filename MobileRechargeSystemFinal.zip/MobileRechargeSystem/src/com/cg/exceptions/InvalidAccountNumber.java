package com.cg.exceptions;

public class InvalidAccountNumber extends Exception {

	public InvalidAccountNumber(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
