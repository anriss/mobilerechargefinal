package com.cg.ui;


import java.util.Scanner;

import com.cg.beans.Account;
import com.cg.exceptions.InvalidAccountNumber;
import com.cg.service.AccountSericeImpl;
import com.cg.service.AccountService;

public class MainUI {
	public static void main(String args[]){
		AccountService accountService = new AccountSericeImpl();
		Account account = new Account();
		Scanner sc= new Scanner(System.in);
		String mobileNumber;
		try{
			System.out.println("Choose amongst the given");
			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter mobile number:");
				mobileNumber=sc.next();
				System.out.println("Your account blance is :"+accountService.getDetails(mobileNumber).getAccountBalance());
				break;

			case 2:
				System.out.println("Enter mobile number ");
				mobileNumber=sc.next();
				System.out.println("Enter recharge amount");
				double rechargeAmount=sc.nextDouble();
				System.out.println(accountService.rechargeAccount(mobileNumber, rechargeAmount));
				System.out.println("Account recharged successfully");
				System.out.println("Hello "+accountService.getDetails(mobileNumber).getCustomerName()+",Available balance is :"+accountService.rechargeAccount(mobileNumber, rechargeAmount));
				break;
			
			case 3:
				System.exit(0);
			}
		}catch(InvalidAccountNumber e)
		{
			e.printStackTrace();
		}
	}
}