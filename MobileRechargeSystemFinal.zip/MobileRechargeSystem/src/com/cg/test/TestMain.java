package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.beans.Account;
import com.cg.exceptions.InvalidAccountNumber;
import com.cg.service.AccountSericeImpl;
import com.cg.service.AccountService;

public class TestMain {
	static AccountService service;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		service= new AccountSericeImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		Account account= new Account("8295636892",new Account("prepaid","rishabh",200));
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testForValidAccount() throws InvalidAccountNumber {
		long actualAmount=(long) service.rechargeAccount("8295636892",100.0);
		long expectedAmount=300;
		Assert.assertEquals(expectedAmount, actualAmount);
	}
	
	@Test(expected=InvalidAccountNumber.class)
	public void testForInvalidAccount() throws InvalidAccountNumber{
		service.rechargeAccount("9815065734", 100);
	}
	

}
