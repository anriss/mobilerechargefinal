package com.cg.service;

import com.cg.beans.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.exceptions.InvalidAccountNumber;

public class AccountSericeImpl implements AccountService{
	AccountDAO accountDAO=new AccountDAOImpl();
	@Override
	public Account getDetails(String mobileNumber) throws InvalidAccountNumber {
		if(accountDAO.getDetails(mobileNumber)==null){
			throw new InvalidAccountNumber("Given Account ID does not exists");
		}
		else
		{
			return accountDAO.getDetails(mobileNumber);
		}
	}

	@Override
	public double rechargeAccount(String mobileNumber, double rechargeAmount) throws InvalidAccountNumber{
		if(accountDAO.getDetails(mobileNumber)==null)
		{
			throw new InvalidAccountNumber("Cannot recharge account as given account ID does not exists");
		}
		double updateAmount=0;
		updateAmount=rechargeAmount+ accountDAO.rechargeAccount(mobileNumber, rechargeAmount);
		return updateAmount;
	}


}
