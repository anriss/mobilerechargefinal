package com.cg.dao;

import java.util.HashMap;

import com.cg.beans.Account;

public class AccountDAOImpl implements AccountDAO{

	HashMap<String,Account>accountEntry;
	public AccountDAOImpl(){
		accountEntry=new HashMap<>();
		accountEntry.put("8295636892",new Account("prepaid","rishabh",200));
		accountEntry.put("9896921889",new Account("prepaid","kumar",500));
		accountEntry.put("9996790646",new Account("prepaid","meenu",600));
		accountEntry.put("9996263179",new Account("prepaid","anirudh",700));
	}

	@Override
	public Account getDetails(String mobileNumber) {
		return	accountEntry.get(mobileNumber);

	}

	@Override
	public double rechargeAccount(String mobileNumber, double rechargeAmount) {
		return accountEntry.get(mobileNumber).getAccountBalance();
	}

}
