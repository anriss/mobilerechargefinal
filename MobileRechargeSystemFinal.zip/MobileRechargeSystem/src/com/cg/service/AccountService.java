package com.cg.service;

import com.cg.beans.Account;
import com.cg.exceptions.InvalidAccountNumber;

public interface AccountService {
Account getDetails(String mobileNumber) throws InvalidAccountNumber;
double rechargeAccount(String mobileNumber,double rechargeAmount) throws InvalidAccountNumber;
}
